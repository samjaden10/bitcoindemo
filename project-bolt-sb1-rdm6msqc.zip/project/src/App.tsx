import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { Hero } from './components/sections/Hero';
import { Markets } from './components/sections/Markets';
import { Register } from './components/auth/Register';
import { Contact } from './components/sections/Contact';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-white">
        <Header />
        <main>
          <Hero />
          <Markets />
          <Register />
          <Contact />
        </main>
        <Footer />
      </div>
    </QueryClientProvider>
  );
}

export default App;