import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { CryptoCard } from '../crypto/CryptoCard';
import { CryptoChart } from '../crypto/CryptoChart';
import { api } from '../../services/api';
import { CryptoAsset } from '../../types/crypto';

export function Markets() {
  const [selectedCrypto, setSelectedCrypto] = React.useState<CryptoAsset | null>(null);
  const { data: cryptos, isLoading } = useQuery({
    queryKey: ['topCryptos'],
    queryFn: api.getTopCryptos
  });

  const { data: chartData } = useQuery({
    queryKey: ['cryptoHistory', selectedCrypto?.id],
    queryFn: () => selectedCrypto ? api.getCryptoHistory(selectedCrypto.id, 7) : null,
    enabled: !!selectedCrypto
  });

  const convertToNGN = (usdPrice: number) => {
    // Using an approximate NGN/USD rate
    const APPROXIMATE_NGN_RATE = 1550;
    return (usdPrice * APPROXIMATE_NGN_RATE).toLocaleString('en-NG', {
      style: 'currency',
      currency: 'NGN'
    });
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <section id="markets" className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Nigerian Cryptocurrency Markets
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Track real-time prices in NGN and USD for top cryptocurrencies
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          <div className="space-y-6">
            {cryptos?.map((crypto) => (
              <div key={crypto.id} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedCrypto(crypto)}>
                <div className="flex items-center space-x-4">
                  <img src={crypto.image} alt={crypto.name} className="w-12 h-12" />
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold">{crypto.name}</h3>
                    <p className="text-gray-500 text-sm">{crypto.symbol.toUpperCase()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-semibold">{convertToNGN(crypto.current_price)}</p>
                    <p className="text-sm text-gray-500">${crypto.current_price.toLocaleString()}</p>
                    <p className={`text-sm ${crypto.price_change_percentage_24h > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {crypto.price_change_percentage_24h > 0 ? '↑' : '↓'} 
                      {Math.abs(crypto.price_change_percentage_24h).toFixed(2)}%
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="lg:sticky lg:top-24 space-y-6">
            {selectedCrypto && chartData && (
              <>
                <CryptoChart
                  data={chartData.prices}
                  label={selectedCrypto.name}
                />
                <div className="bg-white p-6 rounded-xl shadow-md">
                  <h3 className="text-xl font-semibold mb-4">Market Details</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price (NGN)</span>
                      <span className="font-medium">{convertToNGN(selectedCrypto.current_price)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Price (USD)</span>
                      <span className="font-medium">${selectedCrypto.current_price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">24h Change</span>
                      <span className={`font-medium ${selectedCrypto.price_change_percentage_24h > 0 ? 'text-green-500' : 'text-red-500'}`}>
                        {selectedCrypto.price_change_percentage_24h.toFixed(2)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Market Cap</span>
                      <span className="font-medium">${selectedCrypto.market_cap.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}