import React from 'react';
import { Monitor, Smartphone, Globe } from 'lucide-react';

const services = [
  {
    title: 'Web Development',
    description: 'Custom websites built with modern technologies that drive results.',
    icon: Monitor,
  },
  {
    title: 'Mobile Apps',
    description: 'Native and cross-platform mobile applications for iOS and Android.',
    icon: Smartphone,
  },
  {
    title: 'Digital Marketing',
    description: 'Strategic marketing solutions to grow your online presence.',
    icon: Globe,
  },
];

export function Services() {
  return (
    <section id="services" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Our Services
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            We offer comprehensive digital solutions to help your business thrive.
          </p>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <div
              key={service.title}
              className="relative p-8 bg-white border border-gray-200 rounded-2xl shadow-sm flex flex-col hover:border-indigo-600 transition-colors duration-200"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-600 text-white mb-4">
                <service.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900">{service.title}</h3>
              <p className="mt-4 text-base text-gray-500">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}