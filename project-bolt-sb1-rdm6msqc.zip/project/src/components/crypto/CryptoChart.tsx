import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface CryptoChartProps {
  data: [number, number][];
  label: string;
}

export function CryptoChart({ data, label }: CryptoChartProps) {
  const chartData = {
    labels: data.map(([timestamp]) => 
      new Date(timestamp).toLocaleDateString()
    ),
    datasets: [
      {
        label,
        data: data.map(([, value]) => value),
        borderColor: 'rgb(99, 102, 241)',
        backgroundColor: 'rgba(99, 102, 241, 0.1)',
        fill: true,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        display: false,
      },
      title: {
        display: true,
        text: `${label} Price History`,
      },
    },
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <Line options={options} data={chartData} />
    </div>
  );
}