import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { CryptoAsset } from '../../types/crypto';

interface CryptoCardProps {
  crypto: CryptoAsset;
  onClick: (crypto: CryptoAsset) => void;
}

export function CryptoCard({ crypto, onClick }: CryptoCardProps) {
  const isPriceUp = crypto.price_change_percentage_24h > 0;

  return (
    <div
      onClick={() => onClick(crypto)}
      className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer"
    >
      <div className="flex items-center space-x-4">
        <img src={crypto.image} alt={crypto.name} className="w-12 h-12" />
        <div className="flex-1">
          <h3 className="text-lg font-semibold">{crypto.name}</h3>
          <p className="text-gray-500 text-sm">{crypto.symbol.toUpperCase()}</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-semibold">${crypto.current_price.toLocaleString()}</p>
          <p className={`flex items-center text-sm ${isPriceUp ? 'text-green-500' : 'text-red-500'}`}>
            {isPriceUp ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
            {Math.abs(crypto.price_change_percentage_24h).toFixed(2)}%
          </p>
        </div>
      </div>
    </div>
  );
}