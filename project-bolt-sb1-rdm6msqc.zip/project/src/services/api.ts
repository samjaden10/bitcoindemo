import axios from 'axios';
import { CryptoAsset, MarketData } from '../types/crypto';

const API_BASE_URL = 'https://api.coingecko.com/api/v3';

export const api = {
  getTopCryptos: async (): Promise<CryptoAsset[]> => {
    const response = await axios.get(
      `${API_BASE_URL}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&sparkline=false`
    );
    return response.data;
  },

  getCryptoHistory: async (id: string, days: number): Promise<MarketData> => {
    const response = await axios.get(
      `${API_BASE_URL}/coins/${id}/market_chart?vs_currency=usd&days=${days}`
    );
    return response.data;
  }
};